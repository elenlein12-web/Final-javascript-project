// registration.js

const toggleText = document.getElementById("toggleText");
const formTitle = document.getElementById("formTitle");
const authForm = document.getElementById("authForm");
const submitBtn = document.getElementById("submitBtn");

const firstNameInput = document.getElementById("username");
const lastNameInput = document.getElementById("lastname");
const emailInput = document.getElementById("email");
const phoneInput = document.getElementById("phone");
const passwordInput = document.getElementById("password");

let isSignUp = false;
const defaultRole = "user";

// Update form UI depending on Sign Up / Sign In
function updateFormUI() {
  if (isSignUp) {
    formTitle.textContent = "Sign Up";
    submitBtn.textContent = "Sign Up";
    lastNameInput.classList.remove("hidden");
    emailInput.classList.remove("hidden");
    phoneInput.classList.remove("hidden");
    lastNameInput.required = true;
    emailInput.required = true;
    phoneInput.required = true;
    toggleText.innerHTML = `Already have an account? <button type="button" class="toggle-btn" id="toggleBtn">Sign In</button>`;
    document.getElementById("toggleBtn").addEventListener("click", toggleForm);
  } else {
    formTitle.textContent = "Sign In";
    submitBtn.textContent = "Sign In";
    lastNameInput.classList.add("hidden");
    emailInput.classList.remove("hidden"); // required for login
    phoneInput.classList.add("hidden");
    lastNameInput.required = false;
    emailInput.required = true;
    phoneInput.required = false;
    toggleText.innerHTML = `Don't have an account? <button type="button" class="toggle-btn" id="toggleBtn">Sign Up</button>`;
    document.getElementById("toggleBtn").addEventListener("click", toggleForm);
  }
}

// Toggle between Sign In and Sign Up
function toggleForm() {
  isSignUp = !isSignUp;
  updateFormUI();
}

updateFormUI();

// Handle form submission
authForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const firstName = firstNameInput.value.trim();
  const lastName = lastNameInput.value.trim();
  const email = emailInput.value.trim();
  const phone = phoneInput.value.trim();
  const password = passwordInput.value.trim();

  // Validate required fields
  if (
    !password ||
    (isSignUp && (!firstName || !lastName || !email || !phone)) ||
    (!isSignUp && !email)
  ) {
    return Swal.fire("შეცდომა", "გთხოვთ შეავსოთ ყველა ველი", "error");
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^\+?\d{9,15}$/;

  if (!emailRegex.test(email)) {
    return Swal.fire("შეცდომა", "გთხოვთ შეიყვანოთ ვალიდური ელფოსტა", "error");
  }

  if (isSignUp && !phoneRegex.test(phone)) {
    return Swal.fire("შეცდომა", "გთხოვთ შეიყვანოთ სწორი ტელეფონი", "error");
  }

  try {
    const url = isSignUp
      ? "https://rentcar.stepprojects.ge/api/Users/register"
      : "https://rentcar.stepprojects.ge/api/Users/login";

    let bodyData;
    if (isSignUp) {
      bodyData = {
        firstName,
        lastName,
        email,
        password,
        role: defaultRole,
        phoneNumber: phone,
      };
    } else {
      // Sign In: strictly email + password
      bodyData = { email, password };
    }

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bodyData),
    });

    // Safely parse response
    const textData = await res.text();
    let data;
    try {
      data = JSON.parse(textData);
    } catch {
      data = textData;
    }

    if (res.ok) {
      // Store logged in user in localStorage
      const user = {
        id: data.id || data.userId || 0,
        firstName: data.firstName || firstName,
        lastName: data.lastName || lastName,
        email: data.email || email,
        role: data.role || defaultRole,
        phoneNumber: data.phoneNumber || phone,
      };
      localStorage.setItem("loggedInUser", JSON.stringify(user));

      Swal.fire(
        "წარმატება!",
        isSignUp ? "რეგისტრაცია დასრულდა!" : "წარმატებით შესვლა!",
        "success",
      ).then(() => (window.location.href = "index.html"));
    } else {
      // Handle "user already exists" nicely
      if (
        typeof data === "object" &&
        data.message?.includes("already exists")
      ) {
        Swal.fire(
          "შეცდომა",
          "ეს მომხმარებელი უკვე არსებობს. გთხოვთ შედით ან გამოიყენეთ სხვა ელფოსტა.",
          "error",
        );
      } else {
        Swal.fire("შეცდომა", data.message || data || "შეცდომა მოხდა", "error");
      }
    }
  } catch (err) {
    console.error(err);
    Swal.fire("შეცდომა", "სერვერთან დაკავშირება ვერ მოხერხდა", "error");
  }
});
